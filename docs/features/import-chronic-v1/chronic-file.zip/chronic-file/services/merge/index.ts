export class Merge {}
